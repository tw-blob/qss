export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "modules/foundryQuickStatusModule/templates"
    ];
    return loadTemplates(templatePaths);
};
