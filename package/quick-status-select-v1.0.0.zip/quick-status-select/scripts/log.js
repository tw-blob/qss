export function log(msg, ...args) {
    console.log(`quick-status-select | ${msg}`, ...args);
}
