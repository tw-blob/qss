export function debug(msg, ...args) {
    console.log(`quick-status-select | ${msg}`, ...args);
}
