import { preloadTemplates } from '../module/preloadTemplates.js';
import { log } from './log.js';
import { QuickStatusSelectHud } from './quick-select-hud.js';
Hooks.once('init', async function () {
    log('Initializing quick-status-select');
    await preloadTemplates();
});
Hooks.once('canvasReady', async () => {
    log('got canvas ready hook!', game, canvas);
    let user = game.user;
    if (!user) {
        throw new Error('Quick Status Select HUD | No user found.');
    }
    if (!game.quickStatusSelect) {
        game.quickStatusSelect = new QuickStatusSelectHud();
    }
    game.quickStatusSelect.setTokensReference(canvas.tokens);
    Hooks.on('controlToken', (token, controlled) => {
        log('on control token: ', token, controlled);
        if (controlled && hasPermission(token)) {
            game.quickStatusSelect.selectedTokens.push(token);
        }
        else {
            game.quickStatusSelect.selectedTokens.findSplice((t) => t.id === token.id);
            game.quickStatusSelect.searchTerm = '';
            game.quickStatusSelect.close();
        }
    });
    Hooks.on('renderQuickStatusSelectHud', () => {
        game.quickStatusSelect.setQssPosition();
    });
    Hooks.on('renderTokenHUD', (app, html, token) => {
        const effectsButton = html.find('.control-icon.effects');
        effectsButton.mouseup((ev) => {
            ev.preventDefault();
            ev = ev || window.event;
            game.quickStatusSelect.render(true);
        });
    });
    game.quickStatusSelect.updateHud();
});
function hasPermission(token) {
    let actor = token.actor;
    let user = game.user;
    return game.user.isGM || (actor === null || actor === void 0 ? void 0 : actor.hasPerm(user, 'OWNER'));
}
